﻿Public Class HSNRegistrationScreen
    Dim Username As String
    Dim Eamil As String
    Dim Password As String
    Private Sub BackArrow_Click(sender As Object, e As EventArgs) Handles BackArrow.Click
        HSNLoginScreen.Show()
        Me.Close()

    End Sub
End Class