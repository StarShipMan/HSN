﻿Public Class HSNLoginScreen
    Dim Username As String
    Dim Password As String
    Private Sub SignInButton_Click(sender As Object, e As EventArgs) Handles SignInButton.Click
        If UserNameTextBox.Text = "" Or PasswordTextBox.Text = "" Or UserNameTextBox.Text = "Username" Or PasswordTextBox.Text = "Password" Then
            MsgBox("Please enter both a username and password")
        Else
            Username = UserNameTextBox.Text
            Password = PasswordTextBox.Text
            'Code to check database for matching account credentials
        End If
    End Sub

    Private Sub RegisterLinkLabel_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles RegisterLinkLabel.LinkClicked
        HSNRegistrationScreen.Show()
        Me.Hide()
    End Sub
End Class
