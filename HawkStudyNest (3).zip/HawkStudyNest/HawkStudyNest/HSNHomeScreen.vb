﻿Public Class HSNHomeScreen


    'This is for the Notification Logo: Once form is created, decomment the below code to switch to the respective screen.
    'Private Sub ProfileLogo_Click(sender As Object, e As EventArgs) Handles ProfileLogo.Click
    '   HSNProfileScreen.show()
    'Me.Close()
    'End Sub

    'This is for the Notification Logo: Once form is created, decomment the below code to switch to the respective screen.
    'Private Sub NotificationLogo_Click(sender As Object, e As EventArgs) Handles NotificationLogo.Click
    '   HSNNotificationScreen.show()
    'Me.Close()
    'End Sub

    'This is for the Calendar Logo: Once form is created, decomment the below code to switch to the respective screen.
    'Private Sub Calendar_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
    '   HSNMyRooms.show()
    'Me.Close()
    'End Sub

    'This is for the My Room Button: Once form is created, decomment the below code to switch to the respective screen.
    'Private Sub MyRoomsButton_Click(sender As Object, e As EventArgs) Handles MyRoomsButton.Click
    '   HSNMyRooms.Show()
    'Me.Close()
    'End Sub

    'This is for the Schedule a Room Button: Once form is created, decomment the below code to switch to the respective screen.
    'Private Sub ScheduleRoomButton_Click(sender As Object, e As EventArgs) Handles ScheduleRoomButton.Click
    '   HSNScheduleRoomScreen.Show()
    'Me.Close()
    'End Sub
End Class