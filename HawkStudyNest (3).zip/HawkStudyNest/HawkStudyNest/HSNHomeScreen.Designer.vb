﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HSNHomeScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.HomeLabel = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.HomeLogo = New System.Windows.Forms.PictureBox()
        Me.ProfileLogo = New System.Windows.Forms.PictureBox()
        Me.MonmouthLogo = New System.Windows.Forms.PictureBox()
        Me.NotificationLogo = New System.Windows.Forms.PictureBox()
        Me.CalendarLogo = New System.Windows.Forms.PictureBox()
        Me.ScheduleRoomButton = New System.Windows.Forms.Button()
        Me.MyRoomsButton = New System.Windows.Forms.Button()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HomeLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProfileLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MonmouthLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotificationLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CalendarLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'HomeLabel
        '
        Me.HomeLabel.AutoSize = True
        Me.HomeLabel.Font = New System.Drawing.Font("Palatino Linotype", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HomeLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.HomeLabel.Location = New System.Drawing.Point(388, 107)
        Me.HomeLabel.Name = "HomeLabel"
        Me.HomeLabel.Padding = New System.Windows.Forms.Padding(0, 0, 20, 0)
        Me.HomeLabel.Size = New System.Drawing.Size(665, 81)
        Me.HomeLabel.TabIndex = 3
        Me.HomeLabel.Text = "The Hawk Study Nest"
        Me.HomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.HawkStudyNest.My.Resources.Resources.Divider
        Me.PictureBox3.Location = New System.Drawing.Point(8, 217)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(191, 50)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 11
        Me.PictureBox3.TabStop = False
        '
        'HomeLogo
        '
        Me.HomeLogo.Image = Global.HawkStudyNest.My.Resources.Resources.Home
        Me.HomeLogo.Location = New System.Drawing.Point(12, 119)
        Me.HomeLogo.Name = "HomeLogo"
        Me.HomeLogo.Size = New System.Drawing.Size(124, 92)
        Me.HomeLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HomeLogo.TabIndex = 10
        Me.HomeLogo.TabStop = False
        '
        'ProfileLogo
        '
        Me.ProfileLogo.Image = Global.HawkStudyNest.My.Resources.Resources.Profile
        Me.ProfileLogo.Location = New System.Drawing.Point(1178, 10)
        Me.ProfileLogo.Name = "ProfileLogo"
        Me.ProfileLogo.Size = New System.Drawing.Size(141, 98)
        Me.ProfileLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ProfileLogo.TabIndex = 9
        Me.ProfileLogo.TabStop = False
        '
        'MonmouthLogo
        '
        Me.MonmouthLogo.Image = Global.HawkStudyNest.My.Resources.Resources.MonmouthLogo
        Me.MonmouthLogo.Location = New System.Drawing.Point(8, 12)
        Me.MonmouthLogo.Name = "MonmouthLogo"
        Me.MonmouthLogo.Size = New System.Drawing.Size(360, 96)
        Me.MonmouthLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MonmouthLogo.TabIndex = 8
        Me.MonmouthLogo.TabStop = False
        '
        'NotificationLogo
        '
        Me.NotificationLogo.Image = Global.HawkStudyNest.My.Resources.Resources.Notification
        Me.NotificationLogo.Location = New System.Drawing.Point(8, 404)
        Me.NotificationLogo.Name = "NotificationLogo"
        Me.NotificationLogo.Size = New System.Drawing.Size(124, 88)
        Me.NotificationLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.NotificationLogo.TabIndex = 12
        Me.NotificationLogo.TabStop = False
        '
        'CalendarLogo
        '
        Me.CalendarLogo.Image = Global.HawkStudyNest.My.Resources.Resources.Calendar
        Me.CalendarLogo.Location = New System.Drawing.Point(12, 288)
        Me.CalendarLogo.Name = "CalendarLogo"
        Me.CalendarLogo.Size = New System.Drawing.Size(124, 98)
        Me.CalendarLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.CalendarLogo.TabIndex = 13
        Me.CalendarLogo.TabStop = False
        '
        'ScheduleRoomButton
        '
        Me.ScheduleRoomButton.Font = New System.Drawing.Font("Palatino Linotype", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ScheduleRoomButton.ForeColor = System.Drawing.Color.Navy
        Me.ScheduleRoomButton.Location = New System.Drawing.Point(435, 230)
        Me.ScheduleRoomButton.Name = "ScheduleRoomButton"
        Me.ScheduleRoomButton.Size = New System.Drawing.Size(518, 87)
        Me.ScheduleRoomButton.TabIndex = 14
        Me.ScheduleRoomButton.Text = "Schedule A Room"
        Me.ScheduleRoomButton.UseVisualStyleBackColor = True
        '
        'MyRoomsButton
        '
        Me.MyRoomsButton.Font = New System.Drawing.Font("Palatino Linotype", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MyRoomsButton.ForeColor = System.Drawing.Color.Navy
        Me.MyRoomsButton.Location = New System.Drawing.Point(435, 342)
        Me.MyRoomsButton.Name = "MyRoomsButton"
        Me.MyRoomsButton.Size = New System.Drawing.Size(518, 87)
        Me.MyRoomsButton.TabIndex = 15
        Me.MyRoomsButton.Text = "My Rooms"
        Me.MyRoomsButton.UseVisualStyleBackColor = True
        '
        'HSNHomeScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(152, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1331, 590)
        Me.Controls.Add(Me.MyRoomsButton)
        Me.Controls.Add(Me.ScheduleRoomButton)
        Me.Controls.Add(Me.CalendarLogo)
        Me.Controls.Add(Me.NotificationLogo)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.HomeLogo)
        Me.Controls.Add(Me.ProfileLogo)
        Me.Controls.Add(Me.MonmouthLogo)
        Me.Controls.Add(Me.HomeLabel)
        Me.Name = "HSNHomeScreen"
        Me.Text = "HSNHomeScreen"
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HomeLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProfileLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MonmouthLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotificationLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CalendarLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents HomeLabel As Label
    Friend WithEvents MonmouthLogo As PictureBox
    Friend WithEvents ProfileLogo As PictureBox
    Friend WithEvents HomeLogo As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents NotificationLogo As PictureBox
    Friend WithEvents CalendarLogo As PictureBox
    Friend WithEvents ScheduleRoomButton As Button
    Friend WithEvents MyRoomsButton As Button
End Class
