﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HSNLoginScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.SignInLabel = New System.Windows.Forms.Label()
        Me.UserNameTextBox = New System.Windows.Forms.TextBox()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.SignInButton = New System.Windows.Forms.Button()
        Me.RegisterLinkLabel = New System.Windows.Forms.LinkLabel()
        Me.HSNLogo = New System.Windows.Forms.PictureBox()
        Me.MonmouthLogo = New System.Windows.Forms.PictureBox()
        CType(Me.HSNLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MonmouthLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SignInLabel
        '
        Me.SignInLabel.AutoSize = True
        Me.SignInLabel.Font = New System.Drawing.Font("Palatino Linotype", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SignInLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.SignInLabel.Location = New System.Drawing.Point(682, 48)
        Me.SignInLabel.Name = "SignInLabel"
        Me.SignInLabel.Padding = New System.Windows.Forms.Padding(0, 0, 20, 0)
        Me.SignInLabel.Size = New System.Drawing.Size(534, 110)
        Me.SignInLabel.TabIndex = 2
        Me.SignInLabel.Text = "Sign in to your" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Hawk Study Nest Account"
        Me.SignInLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'UserNameTextBox
        '
        Me.UserNameTextBox.BackColor = System.Drawing.SystemColors.ControlLight
        Me.UserNameTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserNameTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.UserNameTextBox.Location = New System.Drawing.Point(768, 202)
        Me.UserNameTextBox.MinimumSize = New System.Drawing.Size(4, 40)
        Me.UserNameTextBox.Name = "UserNameTextBox"
        Me.UserNameTextBox.Size = New System.Drawing.Size(363, 30)
        Me.UserNameTextBox.TabIndex = 3
        Me.UserNameTextBox.Text = "Username"
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PasswordTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PasswordTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.PasswordTextBox.Location = New System.Drawing.Point(768, 267)
        Me.PasswordTextBox.MinimumSize = New System.Drawing.Size(4, 40)
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.Size = New System.Drawing.Size(363, 30)
        Me.PasswordTextBox.TabIndex = 4
        Me.PasswordTextBox.Text = "Password"
        '
        'SignInButton
        '
        Me.SignInButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.SignInButton.Font = New System.Drawing.Font("Palatino Linotype", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SignInButton.Location = New System.Drawing.Point(841, 342)
        Me.SignInButton.Name = "SignInButton"
        Me.SignInButton.Size = New System.Drawing.Size(206, 57)
        Me.SignInButton.TabIndex = 5
        Me.SignInButton.Text = "Sign In"
        Me.SignInButton.UseVisualStyleBackColor = False
        '
        'RegisterLinkLabel
        '
        Me.RegisterLinkLabel.AutoSize = True
        Me.RegisterLinkLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegisterLinkLabel.LinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.RegisterLinkLabel.Location = New System.Drawing.Point(794, 423)
        Me.RegisterLinkLabel.Name = "RegisterLinkLabel"
        Me.RegisterLinkLabel.Size = New System.Drawing.Size(296, 32)
        Me.RegisterLinkLabel.TabIndex = 6
        Me.RegisterLinkLabel.TabStop = True
        Me.RegisterLinkLabel.Text = "Create a New Account"
        '
        'HSNLogo
        '
        Me.HSNLogo.Image = Global.HawkStudyNest.My.Resources.Resources.HawkStudyNestLogo
        Me.HSNLogo.Location = New System.Drawing.Point(128, 138)
        Me.HSNLogo.Name = "HSNLogo"
        Me.HSNLogo.Size = New System.Drawing.Size(519, 360)
        Me.HSNLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HSNLogo.TabIndex = 1
        Me.HSNLogo.TabStop = False
        '
        'MonmouthLogo
        '
        Me.MonmouthLogo.Image = Global.HawkStudyNest.My.Resources.Resources.MonmouthLogo
        Me.MonmouthLogo.Location = New System.Drawing.Point(28, 25)
        Me.MonmouthLogo.Name = "MonmouthLogo"
        Me.MonmouthLogo.Size = New System.Drawing.Size(360, 96)
        Me.MonmouthLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MonmouthLogo.TabIndex = 0
        Me.MonmouthLogo.TabStop = False
        '
        'HSNLoginScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(152, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1342, 565)
        Me.Controls.Add(Me.RegisterLinkLabel)
        Me.Controls.Add(Me.SignInButton)
        Me.Controls.Add(Me.PasswordTextBox)
        Me.Controls.Add(Me.UserNameTextBox)
        Me.Controls.Add(Me.SignInLabel)
        Me.Controls.Add(Me.HSNLogo)
        Me.Controls.Add(Me.MonmouthLogo)
        Me.Name = "HSNLoginScreen"
        Me.Text = "Hawk Study Nest Login Screen"
        CType(Me.HSNLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MonmouthLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MonmouthLogo As PictureBox
    Friend WithEvents HSNLogo As PictureBox
    Friend WithEvents SignInLabel As Label
    Friend WithEvents UserNameTextBox As TextBox
    Friend WithEvents PasswordTextBox As TextBox
    Friend WithEvents SignInButton As Button
    Friend WithEvents RegisterLinkLabel As LinkLabel
End Class
