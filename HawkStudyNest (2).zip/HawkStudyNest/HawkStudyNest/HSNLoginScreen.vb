﻿Public Class HSNLoginScreen
    Dim Username As String
    Dim Password As String
    Private Sub SignInButton_Click(sender As Object, e As EventArgs) Handles SignInButton.Click
        If UserNameTextBox.Text = "" Or PasswordTextBox.Text = "" Or
            UserNameTextBox.Text = "Username" Or PasswordTextBox.Text = "Password" Then
            MsgBox("Please enter a valid input for each field. Note: ""Username"" and ""Password"" are invalid for their respective fields.")
        Else
            Username = UserNameTextBox.Text
            Password = PasswordTextBox.Text
            'Code to check database for matching account credentials
            'If statement follows with If (not succesfull)
            'MsgBox("Login Failed. Note: Either Credentials are incorrect or account does not exist." )
            'Else 
            'HSNHomeScreen.Show()
            'Me.Hide()
        End If
    End Sub

    Private Sub RegisterLinkLabel_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles RegisterLinkLabel.LinkClicked
        HSNRegistrationScreen.Show()
        Me.Hide()
    End Sub
End Class
