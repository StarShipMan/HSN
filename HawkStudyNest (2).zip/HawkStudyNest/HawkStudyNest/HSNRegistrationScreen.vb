﻿Public Class HSNRegistrationScreen
    Dim Username As String
    Dim Email As String
    Dim Password As String
    Dim Confirm
    Private Sub BackArrow_Click(sender As Object, e As EventArgs) Handles BackArrow.Click
        HSNLoginScreen.Show()
        Me.Close()

    End Sub

    Private Sub MonmouthLogo_Click(sender As Object, e As EventArgs) Handles MonmouthLogo.Click
        HSNLoginScreen.Show()
        Me.Close()
    End Sub

    Private Sub CreateAccountButton_Click(sender As Object, e As EventArgs) Handles CreateAccountButton.Click
        If UserNameTextBox.Text = "" Or PasswordTextBox.Text = "" Or EmailTextBox.Text = "" Or
        ConfirmPasswordTextBox.Text = "" Then
            MsgBox("Please ensure that a value has been entered for all fields. Note: At least one of the fields is empty")
        ElseIf UserNameTextBox.Text = "Username" Or PasswordTextBox.Text = "Password" Or EmailTextBox.Text = "Email" Or
            ConfirmPasswordTextBox.Text = "Confirm Password" Then
            MsgBox("Please enter a valid input for each field. Note: ""Username"", ""Email"", ""Password"", and ""Confirm Password"" are invalid for their respective fields.")
        Else
            Username = UserNameTextBox.Text
            Email = EmailTextBox.Text
            Password = PasswordTextBox.Text
            'Code to check database for any possible matches against username or email inputs
            'If there are matches to either then
            'MsgBox (" Username\Email are already used. Please try a different Username\Email)
            ''This will change depending on future versions
            'Else
            'Code to add to database a new user with set credentials from user input.
            Confirm = MsgBox("New Account Created Succesfully. ", [vbOKOnly])
            If Confirm = vbOK Then
                HSNLoginScreen.Show()
                Me.Close()
            End If
        End If
    End Sub


End Class