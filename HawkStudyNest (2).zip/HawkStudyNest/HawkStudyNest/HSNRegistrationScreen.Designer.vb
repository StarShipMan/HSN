﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HSNRegistrationScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CreateAccountButton = New System.Windows.Forms.Button()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.UserNameTextBox = New System.Windows.Forms.TextBox()
        Me.RegistrationLabel = New System.Windows.Forms.Label()
        Me.EmailTextBox = New System.Windows.Forms.TextBox()
        Me.ConfirmPasswordTextBox = New System.Windows.Forms.TextBox()
        Me.HSNLogo = New System.Windows.Forms.PictureBox()
        Me.MonmouthLogo = New System.Windows.Forms.PictureBox()
        Me.BackArrow = New System.Windows.Forms.PictureBox()
        CType(Me.HSNLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MonmouthLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BackArrow, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CreateAccountButton
        '
        Me.CreateAccountButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.CreateAccountButton.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CreateAccountButton.Location = New System.Drawing.Point(836, 448)
        Me.CreateAccountButton.Name = "CreateAccountButton"
        Me.CreateAccountButton.Size = New System.Drawing.Size(206, 57)
        Me.CreateAccountButton.TabIndex = 12
        Me.CreateAccountButton.Text = "Create Account"
        Me.CreateAccountButton.UseVisualStyleBackColor = False
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PasswordTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PasswordTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.PasswordTextBox.Location = New System.Drawing.Point(763, 310)
        Me.PasswordTextBox.MinimumSize = New System.Drawing.Size(4, 40)
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.Size = New System.Drawing.Size(363, 30)
        Me.PasswordTextBox.TabIndex = 11
        Me.PasswordTextBox.Text = "Password"
        '
        'UserNameTextBox
        '
        Me.UserNameTextBox.BackColor = System.Drawing.SystemColors.ControlLight
        Me.UserNameTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserNameTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.UserNameTextBox.Location = New System.Drawing.Point(763, 194)
        Me.UserNameTextBox.MinimumSize = New System.Drawing.Size(4, 40)
        Me.UserNameTextBox.Name = "UserNameTextBox"
        Me.UserNameTextBox.Size = New System.Drawing.Size(363, 30)
        Me.UserNameTextBox.TabIndex = 10
        Me.UserNameTextBox.Text = "Username"
        '
        'RegistrationLabel
        '
        Me.RegistrationLabel.AutoSize = True
        Me.RegistrationLabel.Font = New System.Drawing.Font("Palatino Linotype", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegistrationLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.RegistrationLabel.Location = New System.Drawing.Point(728, 100)
        Me.RegistrationLabel.Name = "RegistrationLabel"
        Me.RegistrationLabel.Padding = New System.Windows.Forms.Padding(0, 0, 20, 0)
        Me.RegistrationLabel.Size = New System.Drawing.Size(447, 55)
        Me.RegistrationLabel.TabIndex = 9
        Me.RegistrationLabel.Text = "Create a New Account"
        Me.RegistrationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'EmailTextBox
        '
        Me.EmailTextBox.BackColor = System.Drawing.SystemColors.ControlLight
        Me.EmailTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmailTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.EmailTextBox.Location = New System.Drawing.Point(763, 252)
        Me.EmailTextBox.MinimumSize = New System.Drawing.Size(4, 40)
        Me.EmailTextBox.Name = "EmailTextBox"
        Me.EmailTextBox.Size = New System.Drawing.Size(363, 30)
        Me.EmailTextBox.TabIndex = 13
        Me.EmailTextBox.Text = "Email"
        '
        'ConfirmPasswordTextBox
        '
        Me.ConfirmPasswordTextBox.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ConfirmPasswordTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ConfirmPasswordTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.ConfirmPasswordTextBox.Location = New System.Drawing.Point(763, 376)
        Me.ConfirmPasswordTextBox.MinimumSize = New System.Drawing.Size(4, 40)
        Me.ConfirmPasswordTextBox.Name = "ConfirmPasswordTextBox"
        Me.ConfirmPasswordTextBox.Size = New System.Drawing.Size(363, 30)
        Me.ConfirmPasswordTextBox.TabIndex = 14
        Me.ConfirmPasswordTextBox.Text = "Confirm Password"
        '
        'HSNLogo
        '
        Me.HSNLogo.Image = Global.HawkStudyNest.My.Resources.Resources.HawkStudyNestLogo
        Me.HSNLogo.Location = New System.Drawing.Point(125, 146)
        Me.HSNLogo.Name = "HSNLogo"
        Me.HSNLogo.Size = New System.Drawing.Size(519, 360)
        Me.HSNLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HSNLogo.TabIndex = 8
        Me.HSNLogo.TabStop = False
        '
        'MonmouthLogo
        '
        Me.MonmouthLogo.Image = Global.HawkStudyNest.My.Resources.Resources.MonmouthLogo
        Me.MonmouthLogo.Location = New System.Drawing.Point(25, 33)
        Me.MonmouthLogo.Name = "MonmouthLogo"
        Me.MonmouthLogo.Size = New System.Drawing.Size(360, 96)
        Me.MonmouthLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MonmouthLogo.TabIndex = 7
        Me.MonmouthLogo.TabStop = False
        '
        'BackArrow
        '
        Me.BackArrow.Image = Global.HawkStudyNest.My.Resources.Resources.BackArrow
        Me.BackArrow.Location = New System.Drawing.Point(12, 501)
        Me.BackArrow.Name = "BackArrow"
        Me.BackArrow.Size = New System.Drawing.Size(110, 89)
        Me.BackArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.BackArrow.TabIndex = 15
        Me.BackArrow.TabStop = False
        '
        'HSNRegistrationScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(152, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1304, 602)
        Me.Controls.Add(Me.BackArrow)
        Me.Controls.Add(Me.ConfirmPasswordTextBox)
        Me.Controls.Add(Me.EmailTextBox)
        Me.Controls.Add(Me.CreateAccountButton)
        Me.Controls.Add(Me.PasswordTextBox)
        Me.Controls.Add(Me.UserNameTextBox)
        Me.Controls.Add(Me.RegistrationLabel)
        Me.Controls.Add(Me.HSNLogo)
        Me.Controls.Add(Me.MonmouthLogo)
        Me.Name = "HSNRegistrationScreen"
        Me.Text = "Hawk Study Nest Registration Screen"
        CType(Me.HSNLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MonmouthLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BackArrow, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CreateAccountButton As Button
    Friend WithEvents PasswordTextBox As TextBox
    Friend WithEvents UserNameTextBox As TextBox
    Friend WithEvents RegistrationLabel As Label
    Friend WithEvents HSNLogo As PictureBox
    Friend WithEvents MonmouthLogo As PictureBox
    Friend WithEvents EmailTextBox As TextBox
    Friend WithEvents ConfirmPasswordTextBox As TextBox
    Friend WithEvents BackArrow As PictureBox
End Class
